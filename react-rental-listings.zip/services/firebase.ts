import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';
import { getStorage } from 'firebase/storage';

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyCC4tGt3qxFvDXYVNqIylYRGHUSAHk4PpA",
  authDomain: "studio-5402619478-70b72.firebaseapp.com",
  projectId: "studio-5402619478-70b72",
  storageBucket: "studio-5402619478-70b72.appspot.com",
  messagingSenderId: "450449513655",
  appId: "1:450449513655:web:dc40c9e1c221f1087bc132"
};


// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Export Firebase services
export const auth = getAuth(app);
export const db = getFirestore(app);
export const storage = getStorage(app);
