
import React from 'react';
import { Property, PropertyType } from '../../types';
import { FiMapPin, FiHome, FiPhone, FiEdit, FiTrash2 } from 'react-icons/fi';
import { FaWhatsapp } from 'react-icons/fa';
import AnimatedButton from '../ui/AnimatedButton';

interface PropertyCardProps {
  property: Property;
  variant: 'home' | 'profile';
  onEdit?: (id: string) => void;
  onDelete?: (id: string) => void;
}

const PropertyTypeIcon: React.FC<{ type: PropertyType }> = ({ type }) => {
  const icons: Record<PropertyType, React.ReactNode> = {
    [PropertyType.House]: <FiHome className="mr-2" />,
    [PropertyType.Shop]: <span className="mr-2 text-lg">🏬</span>,
    [PropertyType.Apartment]: <span className="mr-2 text-lg">🏢</span>,
  };
  return <>{icons[type]}</>;
};

const PropertyCard: React.FC<PropertyCardProps> = ({ property, variant, onEdit, onDelete }) => {
  const { id, title, address, city, area, imageUrl, phone, whatsapp, type, bedrooms, bathrooms } = property;

  return (
    <div className="bg-base-100 rounded-lg shadow-lg overflow-hidden transform hover:-translate-y-1 transition-transform duration-300 flex flex-col">
      <img src={imageUrl} alt={title} className="w-full h-48 object-cover" />
      <div className="p-4 flex flex-col flex-grow">
        <div className="flex justify-between items-start mb-2">
            <h3 className="text-xl font-bold text-primary truncate pr-2">{title}</h3>
            <span className="flex items-center text-sm bg-accent text-white px-2 py-1 rounded">
                <PropertyTypeIcon type={type} /> {type}
            </span>
        </div>
        
        <p className="text-lg font-semibold text-neutral mb-1 flex items-center">
            <FiMapPin className="mr-2 text-gray-500" />
            <span className="font-extrabold text-xl">{address}</span>
        </p>

        <div className="flex justify-between items-baseline mb-4">
            <p className="text-md text-gray-600">{area}</p>
            <p className="text-xl font-bold text-secondary">{city}</p>
        </div>

        <div className="flex-grow text-sm text-gray-500 space-y-2 mb-4">
            <div className="flex items-center">
                <span className="font-bold mr-2">Bedrooms:</span> {bedrooms}
            </div>
             <div className="flex items-center">
                <span className="font-bold mr-2">Bathrooms:</span> {bathrooms}
            </div>
        </div>

        <div className="mt-auto pt-4 border-t border-base-200">
          {variant === 'home' && (
            <div className="flex justify-around items-center">
              <a href={`tel:${phone}`} className="w-full mr-2">
                <AnimatedButton className="bg-green-500 hover:bg-green-600 text-white w-full">
                  <FiPhone className="mr-2" /> Call
                </AnimatedButton>
              </a>
              <a href={`https://wa.me/${whatsapp}`} target="_blank" rel="noopener noreferrer" className="w-full ml-2">
                <AnimatedButton className="bg-teal-500 hover:bg-teal-600 text-white w-full animate-pulse-slow">
                  <FaWhatsapp className="mr-2" /> WhatsApp
                </AnimatedButton>
              </a>
            </div>
          )}
          {variant === 'profile' && onEdit && onDelete && (
            <div className="flex justify-around items-center">
              <AnimatedButton onClick={() => onEdit(id)} className="bg-accent hover:bg-blue-700 text-white w-full mr-2">
                <FiEdit className="mr-2" /> Edit
              </AnimatedButton>
              <AnimatedButton onClick={() => onDelete(id)} className="bg-red-500 hover:bg-red-600 text-white w-full ml-2">
                <FiTrash2 className="mr-2" /> Delete
              </AnimatedButton>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default PropertyCard;
