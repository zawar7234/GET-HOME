
import React from 'react';
import { NavLink } from 'react-router-dom';
import { FiHome, FiUser, FiInfo, FiShield, FiX, FiPlusCircle } from 'react-icons/fi';
import { useAuth } from '../../hooks/useAuth';

interface SidebarProps {
  isOpen: boolean;
  setIsOpen: (isOpen: boolean) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ isOpen, setIsOpen }) => {
    const { currentUser } = useAuth();

    const commonLinkClasses = "flex items-center p-3 my-1 rounded-lg transition-colors duration-200";
    const activeLinkClasses = "bg-primary text-white shadow-lg";
    const inactiveLinkClasses = "text-gray-600 hover:bg-base-300 hover:text-primary";

    const getLinkClass = ({ isActive }: { isActive: boolean }) => 
      `${commonLinkClasses} ${isActive ? activeLinkClasses : inactiveLinkClasses}`;

  return (
    <>
      <div
        className={`fixed inset-0 bg-black bg-opacity-50 z-20 transition-opacity lg:hidden ${
          isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'
        }`}
        onClick={() => setIsOpen(false)}
      ></div>
      <aside
        className={`bg-base-100 text-neutral w-64 min-h-screen space-y-6 py-7 px-2 absolute inset-y-0 left-0 transform ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        } lg:relative lg:translate-x-0 transition duration-200 ease-in-out z-30 shadow-lg`}
      >
        <div className="flex items-center justify-between px-2">
            <h2 className="text-2xl font-extrabold text-primary">Menu</h2>
            <button onClick={() => setIsOpen(false)} className="lg:hidden">
                <FiX className="h-6 w-6"/>
            </button>
        </div>
        <nav>
          <NavLink to="/" className={getLinkClass}>
            <FiHome className="h-5 w-5 mr-3" />
            Home
          </NavLink>
          {currentUser && (
            <>
              <NavLink to="/profile" className={getLinkClass}>
                <FiUser className="h-5 w-5 mr-3" />
                Profile
              </NavLink>
               <NavLink to="/add-property" className={getLinkClass}>
                <FiPlusCircle className="h-5 w-5 mr-3" />
                Add Property
              </NavLink>
            </>
          )}
          <NavLink to="/about" className={getLinkClass}>
            <FiInfo className="h-5 w-5 mr-3" />
            About Us
          </NavLink>
          <NavLink to="/privacy" className={getLinkClass}>
            <FiShield className="h-5 w-5 mr-3" />
            Privacy Policy
          </NavLink>
        </nav>
      </aside>
    </>
  );
};

export default Sidebar;
