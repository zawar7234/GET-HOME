
import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { FiMenu, FiLogIn, FiLogOut, FiUser } from 'react-icons/fi';
import { useAuth } from '../../hooks/useAuth';
import { signOut } from 'firebase/auth';
import { auth } from '../../services/firebase';
import AnimatedButton from '../ui/AnimatedButton';

interface HeaderProps {
  toggleSidebar: () => void;
}

const Header: React.FC<HeaderProps> = ({ toggleSidebar }) => {
  const { currentUser } = useAuth();
  const navigate = useNavigate();

  const handleLogout = async () => {
    try {
      await signOut(auth);
      navigate('/login');
    } catch (error) {
      console.error('Error signing out: ', error);
    }
  };

  return (
    <header className="bg-base-100 shadow-md p-4 flex items-center justify-between z-10">
      <div className="flex items-center">
        <button
          onClick={toggleSidebar}
          className="text-gray-600 focus:outline-none lg:hidden mr-4"
        >
          <FiMenu className="h-6 w-6" />
        </button>
        <h1 className="text-xl font-bold text-primary">Rental Listings</h1>
      </div>
      <div className="flex items-center space-x-4">
        {currentUser ? (
          <>
            <Link to="/profile" className="flex items-center text-neutral hover:text-primary">
              <FiUser className="h-5 w-5 mr-1" />
              <span>{currentUser.email}</span>
            </Link>
            <AnimatedButton onClick={handleLogout} className="bg-red-500 hover:bg-red-600 text-white">
              <FiLogOut className="h-5 w-5 mr-2" />
              Logout
            </AnimatedButton>
          </>
        ) : (
          <AnimatedButton onClick={() => navigate('/login')} className="bg-primary hover:bg-blue-800 text-white">
            <FiLogIn className="h-5 w-5 mr-2" />
            Login
          </AnimatedButton>
        )}
      </div>
    </header>
  );
};

export default Header;
