
import { Timestamp } from 'firebase/firestore';

export enum PropertyType {
  House = 'House',
  Shop = 'Shop',
  Apartment = 'Apartment',
}

export interface Property {
  id: string;
  userId: string;
  title: string;
  address: string;
  type: PropertyType;
  country: string;
  city: string;
  area: string;
  bedrooms: number;
  bathrooms: number;
  hasGas: boolean;
  hasElectricity: boolean;
  whatsapp: string;
  phone: string;
  imageUrl: string;
  createdAt: Timestamp;
}
