
import React from 'react';

const AboutPage: React.FC = () => {
  return (
    <div className="p-4 sm:p-6 lg:p-8">
      <div className="max-w-4xl mx-auto bg-base-100 p-8 rounded-lg shadow-md prose">
        <h1 className="text-3xl font-bold text-primary mb-4">About Us</h1>
        <p>
          We are dedicated to providing the best rental listing platform. Our mission is to connect landlords with tenants in a seamless and efficient manner.
        </p>
        <p>
          This application is built with modern web technologies to ensure a fast, reliable, and user-friendly experience.
        </p>
      </div>
    </div>
  );
};

export default AboutPage;
