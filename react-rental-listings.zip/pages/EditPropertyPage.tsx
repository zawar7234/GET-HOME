
import React from 'react';
import { useParams } from 'react-router-dom';

const EditPropertyPage: React.FC = () => {
  const { id } = useParams();
  return (
    <div className="p-4 sm:p-6 lg:p-8">
      <div className="max-w-4xl mx-auto bg-base-100 p-8 rounded-lg shadow-md">
        <h1 className="text-3xl font-bold text-primary mb-4">Edit Property</h1>
        <p className="text-lg text-neutral">You are editing property with ID: <span className="font-semibold text-accent">{id}</span></p>
      </div>
    </div>
  );
};

export default EditPropertyPage;
