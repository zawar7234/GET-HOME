import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { collection, addDoc, serverTimestamp } from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { db, storage } from '../services/firebase';
import { useAuth } from '../hooks/useAuth';
import { countries } from '../data/countries';
import { PropertyType } from '../types';
import AnimatedButton from '../components/ui/AnimatedButton';
import Spinner from '../components/ui/Spinner';
import { FiUpload, FiAlertCircle } from 'react-icons/fi';

const AddPropertyPage: React.FC = () => {
  const [formData, setFormData] = useState({
    title: '',
    address: '',
    type: PropertyType.House,
    country: 'United States of America',
    city: '',
    area: '',
    bedrooms: 1,
    bathrooms: 1,
    hasGas: false,
    hasElectricity: false,
    whatsapp: '',
    phone: '',
  });
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [imagePreview, setImagePreview] = useState<string | null>(null);

  const { currentUser } = useAuth();
  const navigate = useNavigate();

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    if (type === 'checkbox') {
        const { checked } = e.target as HTMLInputElement;
        setFormData(prev => ({ ...prev, [name]: checked }));
    } else {
        setFormData(prev => ({ ...prev, [name]: value }));
    }
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setImageFile(file);
      setImagePreview(URL.createObjectURL(file));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) {
      setError('You must be logged in to add a property.');
      return;
    }
    if (!imageFile) {
      setError('Please upload an image for the property.');
      return;
    }

    setLoading(true);
    setError('');

    try {
      const imageRef = ref(storage, `properties/${currentUser.uid}-${Date.now()}-${imageFile.name}`);
      const snapshot = await uploadBytes(imageRef, imageFile);
      const imageUrl = await getDownloadURL(snapshot.ref);

      await addDoc(collection(db, 'properties'), {
        ...formData,
        bedrooms: Number(formData.bedrooms),
        bathrooms: Number(formData.bathrooms),
        userId: currentUser.uid,
        imageUrl,
        createdAt: serverTimestamp(),
      });
      
      navigate('/profile');
    } catch (err) {
      console.error(err);
      setError('Failed to add property. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const inputClasses = "w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-accent";
  const checkboxClasses = "h-5 w-5 rounded text-primary focus:ring-primary";

  return (
    <div className="p-4 sm:p-6 lg:p-8">
      <div className="max-w-4xl mx-auto bg-base-100 p-8 rounded-lg shadow-md">
        <h1 className="text-3xl font-bold text-primary mb-6">Add New Property</h1>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <input type="text" name="title" placeholder="Property Title" value={formData.title} onChange={handleInputChange} className={inputClasses} required />
            <input type="text" name="address" placeholder="Address" value={formData.address} onChange={handleInputChange} className={inputClasses} required />
            <select name="type" value={formData.type} onChange={handleInputChange} className={inputClasses} required>
              {Object.values(PropertyType).map(type => <option key={type} value={type}>{type}</option>)}
            </select>
            <select name="country" value={formData.country} onChange={handleInputChange} className={inputClasses} required>
              {countries.map(country => <option key={country} value={country}>{country}</option>)}
            </select>
            <input type="text" name="city" placeholder="City" value={formData.city} onChange={handleInputChange} className={inputClasses} required />
            <input type="text" name="area" placeholder="Area (e.g., 1200 sqft)" value={formData.area} onChange={handleInputChange} className={inputClasses} required />
            <input type="number" name="bedrooms" placeholder="Bedrooms" min="0" value={formData.bedrooms} onChange={handleInputChange} className={inputClasses} required />
            <input type="number" name="bathrooms" placeholder="Bathrooms" min="0" value={formData.bathrooms} onChange={handleInputChange} className={inputClasses} required />
            <input type="tel" name="phone" placeholder="Phone Number" value={formData.phone} onChange={handleInputChange} className={inputClasses} required />
            <input type="text" name="whatsapp" placeholder="WhatsApp Number (with country code)" value={formData.whatsapp} onChange={handleInputChange} className={inputClasses} required />
          </div>
          <div className="flex items-center space-x-6">
             <label className="flex items-center cursor-pointer">
                <input type="checkbox" name="hasGas" checked={formData.hasGas} onChange={handleInputChange} className={checkboxClasses} />
                <span className="ml-2 text-gray-700">Gas Available</span>
            </label>
             <label className="flex items-center cursor-pointer">
                <input type="checkbox" name="hasElectricity" checked={formData.hasElectricity} onChange={handleInputChange} className={checkboxClasses} />
                <span className="ml-2 text-gray-700">Electricity Available</span>
            </label>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Property Image</label>
            <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-md">
              <div className="space-y-1 text-center">
                {imagePreview ? (
                    <img src={imagePreview} alt="Property Preview" className="mx-auto h-48 w-auto rounded-md object-cover" />
                ) : (
                    <FiUpload className="mx-auto h-12 w-12 text-gray-400" />
                )}
                <div className="flex justify-center text-sm text-gray-600">
                  <label htmlFor="file-upload" className="relative cursor-pointer bg-white rounded-md font-medium text-primary hover:text-accent focus-within:outline-none">
                    <span>{imageFile ? "Change image" : "Upload an image"}</span>
                    <input id="file-upload" name="file-upload" type="file" className="sr-only" onChange={handleImageChange} accept="image/*" />
                  </label>
                </div>
                <p className="text-xs text-gray-500">PNG, JPG up to 10MB</p>
              </div>
            </div>
          </div>
          
          {error && (
            <div className="flex items-center p-3 text-sm text-red-700 bg-red-100 rounded-lg" role="alert">
              <FiAlertCircle className="w-5 h-5 mr-2"/>
              <span className="font-medium">{error}</span>
            </div>
          )}

          <div className="flex justify-end pt-4">
            <AnimatedButton type="submit" disabled={loading} className="bg-primary hover:bg-blue-800 text-white w-full md:w-auto">
              {loading ? <span className="flex items-center"><Spinner /> <span className="ml-2">Adding...</span></span> : 'Add Property'}
            </AnimatedButton>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AddPropertyPage;