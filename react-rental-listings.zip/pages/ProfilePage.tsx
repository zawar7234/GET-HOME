import React, { useEffect, useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { collection, query, where, getDocs, doc, deleteDoc } from 'firebase/firestore';
import { ref, deleteObject } from 'firebase/storage';
import { db, storage } from '../services/firebase';
import { useAuth } from '../hooks/useAuth';
import { Property } from '../types';
import PropertyCard from '../components/property/PropertyCard';
import Spinner from '../components/ui/Spinner';
import AnimatedButton from '../components/ui/AnimatedButton';
import { FiPlus } from 'react-icons/fi';

const ProfilePage: React.FC = () => {
  const [properties, setProperties] = useState<Property[]>([]);
  const [loading, setLoading] = useState(true);
  const { currentUser } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    const fetchProperties = async () => {
      if (!currentUser) {
        setLoading(false);
        return;
      }
      try {
        const q = query(
          collection(db, 'properties'),
          where('userId', '==', currentUser.uid)
          // Removed orderBy('createdAt', 'desc') to avoid needing a composite index.
          // Sorting will be done on the client side.
        );
        const querySnapshot = await getDocs(q);
        const userProperties = querySnapshot.docs.map(doc => ({
          id: doc.id,
          ...doc.data(),
        })) as Property[];

        // Sort properties by creation date (newest first) on the client.
        userProperties.sort((a, b) => {
          if (a.createdAt && b.createdAt) {
            return b.createdAt.toMillis() - a.createdAt.toMillis();
          }
          return 0;
        });
        
        setProperties(userProperties);
      } catch (error) {
        console.error("Error fetching properties: ", error);
      } finally {
        setLoading(false);
      }
    };

    fetchProperties();
  }, [currentUser]);

  const handleEdit = (id: string) => {
    navigate(`/edit-property/${id}`);
  };

  const handleDelete = async (id: string) => {
    if (window.confirm('Are you sure you want to delete this property? This action cannot be undone.')) {
      try {
        const propertyToDelete = properties.find(p => p.id === id);
        if (propertyToDelete) {
          // Delete image from storage
          const imageRef = ref(storage, propertyToDelete.imageUrl);
          await deleteObject(imageRef);
          
          // Delete document from firestore
          await deleteDoc(doc(db, 'properties', id));
          
          // Update state
          setProperties(properties.filter(p => p.id !== id));
        }
      } catch (error) {
        console.error("Error deleting property: ", error);
        alert("Failed to delete property. Please try again.");
      }
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-full">
        <Spinner />
      </div>
    );
  }

  return (
    <div className="p-4 sm:p-6 lg:p-8">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-center mb-8">
            <h1 className="text-4xl font-extrabold text-primary mb-4 md:mb-0">My Properties</h1>
            <Link to="/add-property">
                <AnimatedButton className="bg-accent hover:bg-blue-700 text-white">
                    <FiPlus className="mr-2 h-5 w-5" />
                    Add New Property
                </AnimatedButton>
            </Link>
        </div>
        
        {properties.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {properties.map(property => (
              <PropertyCard 
                key={property.id} 
                property={property} 
                variant="profile"
                onEdit={handleEdit}
                onDelete={handleDelete}
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-16 px-6 bg-base-100 rounded-lg shadow-md">
            <h2 className="text-2xl font-semibold text-neutral">No Properties Found</h2>
            <p className="text-gray-500 mt-2">You haven't listed any properties yet. Click the button above to get started!</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default ProfilePage;