import React, { useEffect, useState } from 'react';
import { collection, getDocs, orderBy, query } from 'firebase/firestore';
import { db } from '../services/firebase';
import { Property } from '../types';
import PropertyCard from '../components/property/PropertyCard';
import Spinner from '../components/ui/Spinner';

const HomePage: React.FC = () => {
  const [properties, setProperties] = useState<Property[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchProperties = async () => {
      try {
        const q = query(collection(db, 'properties'), orderBy('createdAt', 'desc'));
        const querySnapshot = await getDocs(q);
        const allProperties = querySnapshot.docs.map(doc => ({
          id: doc.id,
          ...doc.data(),
        })) as Property[];
        setProperties(allProperties);
      } catch (error) {
        console.error("Error fetching properties: ", error);
      } finally {
        setLoading(false);
      }
    };

    fetchProperties();
  }, []);

  return (
    <div className="p-4 sm:p-6 lg:p-8">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-12">
            <h1 className="text-4xl md:text-5xl font-extrabold text-primary mb-4">Find Your Next Home</h1>
            <p className="text-lg text-neutral max-w-3xl mx-auto">
            Browse our curated list of properties. The perfect rental is just a few clicks away.
            </p>
        </div>
        
        {loading ? (
             <div className="flex justify-center items-center h-64">
                <Spinner />
            </div>
        ) : properties.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {properties.map(property => (
              <PropertyCard key={property.id} property={property} variant="home" />
            ))}
          </div>
        ) : (
             <div className="text-center py-16 px-6 bg-base-100 rounded-lg shadow-md">
                <h2 className="text-2xl font-semibold text-neutral">No Properties Available</h2>
                <p className="text-gray-500 mt-2">Please check back later, or be the first to list a property!</p>
            </div>
        )}
      </div>
    </div>
  );
};

export default HomePage;