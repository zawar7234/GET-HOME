import React, { useState, lazy, Suspense } from 'react';
import { HashRouter, Routes, Route } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import ProtectedRoute from './components/auth/ProtectedRoute';

import Sidebar from './components/layout/Sidebar';
import Header from './components/layout/Header';
import Spinner from './components/ui/Spinner';

// Lazy load page components
const HomePage = lazy(() => import('./pages/HomePage'));
const ProfilePage = lazy(() => import('./pages/ProfilePage'));
const AddPropertyPage = lazy(() => import('./pages/AddPropertyPage'));
const EditPropertyPage = lazy(() => import('./pages/EditPropertyPage'));
const AboutPage = lazy(() => import('./pages/AboutPage'));
const PrivacyPolicyPage = lazy(() => import('./pages/PrivacyPolicyPage'));
const LoginPage = lazy(() => import('./pages/LoginPage'));

function App() {
  const [isSidebarOpen, setSidebarOpen] = useState(false);

  return (
    <AuthProvider>
      <HashRouter>
        <div className="flex h-screen bg-base-200 font-sans">
          <Sidebar isOpen={isSidebarOpen} setIsOpen={setSidebarOpen} />
          <div className="flex-1 flex flex-col overflow-hidden">
            <Header toggleSidebar={() => setSidebarOpen(!isSidebarOpen)} />
            <main className="flex-1 overflow-x-hidden overflow-y-auto bg-base-200 p-4 md:p-6 lg:p-8">
              <Suspense fallback={
                <div className="flex justify-center items-center h-full">
                  <Spinner />
                </div>
              }>
                <Routes>
                  <Route path="/login" element={<LoginPage />} />
                  <Route path="/" element={<HomePage />} />
                  <Route path="/about" element={<AboutPage />} />
                  <Route path="/privacy" element={<PrivacyPolicyPage />} />
                  <Route 
                    path="/profile" 
                    element={
                      <ProtectedRoute>
                        <ProfilePage />
                      </ProtectedRoute>
                    } 
                  />
                  <Route 
                    path="/add-property" 
                    element={
                      <ProtectedRoute>
                        <AddPropertyPage />
                      </ProtectedRoute>
                    } 
                  />
                  <Route 
                    path="/edit-property/:id" 
                    element={
                      <ProtectedRoute>
                        <EditPropertyPage />
                      </ProtectedRoute>
                    } 
                  />
                </Routes>
              </Suspense>
            </main>
          </div>
        </div>
      </HashRouter>
    </AuthProvider>
  );
}

export default App;